<#
Setup-PrintHelper.ps1  v2  -  installs or updates the "BT Print" label helper on a Windows PC.
=====================================================================================
Normally started by Setup.cmd (which asks for Administrator rights). Works from
  * the extracted one-file installer (Setup.cmd + Setup-PrintHelper.ps1 + payload.zip), or
  * the kit folder (Setup.cmd + Setup-PrintHelper.ps1 + helper\ + driver\).

What it does
  1. copies helper v2 (btprint.ps1, label.html, settings.json, README.txt) to C:\PrintHelper
     (an existing settings.json is kept, so updates do not lose the printer choice)
  2. printer: Arkscan on the network -> installs the bundled driver, TCP/IP RAW port and printer
              Arkscan by USB        -> installs the bundled driver, waits for Windows to add the printer
              any other printer     -> opens Windows' own Add Printer page (Windows Update supplies the
                                       driver) and waits until the new printer appears
  3. Startup shortcut "BT Print Server.lnk" + scheduled task "BT Print Server watchdog" (every 30 min)
     for the logged-on user, exactly like the shop's main PC, then starts the helper
  4. opens http://localhost:<port>/setup for the printer / paper / label size choice and a test label
  5. CHECKUP with PASS/FAIL per item, ending in ALL GOOD or a list of fixes.

Parameters (all optional)
  -InstallDir    default C:\PrintHelper
  -Port          helper port, default 8765 (the Zoho app calls http://localhost:8765)
  -PrinterName   Windows name of the label printer. For a new network Arkscan default "Arkscan 2054K_WF".
  -PrinterIP     IP of a network Arkscan, default 192.168.1.81 (shop network)
  -PrinterKind   auto | arkscan-network | arkscan-usb | other | skip   (auto = ask, or detect when -NoPrompt)
  -SkipTestPrint no label stock loaded yet
  -CheckOnly     only run the checkup against an existing install
  -NoPrompt      never wait for keyboard input (for unattended/scripted runs)
  -Force         continue even if a btprint listener runs from another folder (used when replacing v1)
  -TaskName / -ShortcutName   override the autostart names (only for side-by-side tests)
#>
[CmdletBinding()]
param(
  [string]$InstallDir   = 'C:\PrintHelper',
  [int]$Port            = 8765,
  [string]$PrinterName  = '',
  [string]$PrinterIP    = '192.168.1.81',
  [ValidateSet('auto','arkscan-network','arkscan-usb','other','skip')][string]$PrinterKind = 'auto',
  [switch]$SkipTestPrint,
  [switch]$CheckOnly,
  [switch]$NoPrompt,
  [switch]$Force,
  [string]$TaskName     = 'BT Print Server watchdog',
  [string]$ShortcutName = 'BT Print Server.lnk'
)

$ErrorActionPreference = 'Stop'
$KitDir       = Split-Path -Parent $MyInvocation.MyCommand.Path
$DriverName   = 'Arkscan 2054K'
$ArkDefault   = 'Arkscan 2054K_WF'
$HelperFiles  = @('btprint.ps1', 'label.html', 'README.txt')
$ExitCode     = 0

# ----------------------------------------------------------------------------- helpers
function Say($m)  { Write-Host $m }
function Step($m) { Write-Host ""; Write-Host ("==> " + $m) -ForegroundColor Cyan }
function Warn($m) { Write-Host ("    ! " + $m) -ForegroundColor Yellow }
function Ask($prompt, $default = '') {
  if ($NoPrompt) { return $default }
  $a = Read-Host $prompt
  if ([string]::IsNullOrWhiteSpace($a)) { return $default } else { return $a.Trim() }
}
function Test-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  (New-Object Security.Principal.WindowsPrincipal $id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Get-Url($path, $timeout = 8) {
  try { $r = Invoke-WebRequest -Uri ("http://localhost:{0}{1}" -f $Port, $path) -UseBasicParsing -TimeoutSec $timeout; return [string]$r.Content } catch { return $null }
}
function Get-ListenerProcesses {
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
    Where-Object { $_.CommandLine -match 'btprint\.ps1' -and $_.CommandLine -match '-Serve(\s|$)' }
}
function Get-TargetUser {
  # The helper must run as the person who sits at the PC (the browser calls localhost), not as the admin
  # account that happens to run this script. Prefer the console user; fall back to the current user.
  $name = $null
  try { $name = (Get-CimInstance Win32_ComputerSystem).UserName } catch {}
  if (-not $name) { $name = "$env:USERDOMAIN\$env:USERNAME" }
  $sid = $null; $profilePath = $null
  try { $sid = (New-Object Security.Principal.NTAccount($name)).Translate([Security.Principal.SecurityIdentifier]).Value } catch {}
  if ($sid) { try { $profilePath = (Get-CimInstance Win32_UserProfile -Filter "SID='$sid'").LocalPath } catch {} }
  if (-not $profilePath) { $profilePath = $env:USERPROFILE }
  [pscustomobject]@{
    Name          = $name
    ProfilePath   = $profilePath
    StartupFolder = Join-Path $profilePath 'AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup'
    IsCurrentUser = ($name -ieq "$env:USERDOMAIN\$env:USERNAME")
  }
}
function Test-Tcp($hostName, $tcpPort, $ms = 3000) {
  try { $c = New-Object Net.Sockets.TcpClient; $ar = $c.BeginConnect($hostName, [int]$tcpPort, $null, $null); $ok = $ar.AsyncWaitHandle.WaitOne($ms) -and $c.Connected; $c.Close(); return $ok } catch { return $false }
}
function Read-Settings($file) {
  if (Test-Path $file) { try { return (Get-Content $file -Raw -Encoding UTF8 | ConvertFrom-Json) } catch {} }
  return $null
}
function Write-Settings($file, $printer, $paper, $w, $h, $portNo) {
  $o = [ordered]@{ version = '2.1.2'; printerName = [string]$printer; paperName = [string]$paper; labelWidthIn = [double]$w; labelHeightIn = [double]$h; port = [int]$portNo }
  [IO.File]::WriteAllText($file, ($o | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
}
function Install-ArkscanDriver($inf) {
  if (Get-PrinterDriver -Name $DriverName -ErrorAction SilentlyContinue) { Say "Driver '$DriverName' already present."; return }
  if (-not (Test-Path $inf)) { throw "Driver package missing: $inf" }
  Say "Adding driver package $inf"
  & pnputil.exe /add-driver "$inf" /install | Out-Null
  Add-PrinterDriver -Name $DriverName
  Say "Driver '$DriverName' installed."
}

$ServeArgs = "--headless powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File $InstallDir\btprint.ps1 -ServeHidden"
$IsAdmin   = Test-Admin
$User      = Get-TargetUser
$Payload   = $null

try {
# ----------------------------------------------------------------------------- locate the files
Step "BT Print helper v2 setup on $env:COMPUTERNAME"
$HelperSrc = Join-Path $KitDir 'helper'
$DriverInf = Join-Path $KitDir 'driver\arkprtv6\arkprtv6.inf'
$zip = Join-Path $KitDir 'payload.zip'
if (-not (Test-Path $HelperSrc) -and (Test-Path $zip)) {
  $Payload = Join-Path $env:TEMP ('btprint-setup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
  New-Item -ItemType Directory -Force -Path $Payload | Out-Null
  Expand-Archive -Path $zip -DestinationPath $Payload -Force
  $HelperSrc = Join-Path $Payload 'helper'
  $DriverInf = Join-Path $Payload 'driver\arkprtv6\arkprtv6.inf'
}
Say "Files from      : $(Split-Path -Parent $HelperSrc)"
Say "Install folder  : $InstallDir"
Say "Port            : $Port"
Say "Runs as user    : $($User.Name)   startup folder: $($User.StartupFolder)"
Say "Administrator   : $IsAdmin"
if (-not $User.IsCurrentUser) { Warn "You are elevated as a different account than the logged-on user. Startup entries go to $($User.Name)." }
if ($PSVersionTable.PSVersion.Major -lt 5) { throw 'Windows PowerShell 5.1 or newer is required.' }

if (-not $CheckOnly) {
  if (-not (Test-Path (Join-Path $HelperSrc 'btprint.ps1'))) { throw "helper\btprint.ps1 not found next to this script (or in payload.zip)." }

  # --------------------------------------------------------------------------- 0. another listener?
  Step "Checking port $Port"
  # Only the process that holds OUR port is ever touched; helpers on other ports are left alone.
  $ownerPid = $null
  try { $ownerPid = (Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction Stop | Select-Object -First 1).OwningProcess } catch {}
  if ($ownerPid) {
    $owner = Get-CimInstance Win32_Process -Filter "ProcessId=$ownerPid" -ErrorAction SilentlyContinue
    $cmd = if ($owner) { [string]$owner.CommandLine } else { '' }
    if ($cmd -match [regex]::Escape($InstallDir)) {
      Say "Stopping the existing helper from $InstallDir (pid $ownerPid) so its files can be refreshed."
      Stop-Process -Id $ownerPid -Force -ErrorAction SilentlyContinue; Start-Sleep -Seconds 2
    } elseif ($cmd -match 'btprint\.ps1') {
      Warn ("Port $Port is held by another BT Print helper: pid {0}: {1}" -f $ownerPid, $cmd)
      if (-not $Force) { throw "Another BT Print helper already uses port $Port on this PC. Re-run with -Force to replace it (its folder is left in place as a backup)." }
      Say 'Stopping it (-Force). Its folder is not deleted.'
      Stop-Process -Id $ownerPid -Force -ErrorAction SilentlyContinue; Start-Sleep -Seconds 2
    } else {
      throw ("Port $Port is in use by another program (pid {0}: {1}). Choose another port with -Port or stop that program." -f $ownerPid, $cmd)
    }
  }
  # stale listeners of this very install folder on other ports (e.g. after a port change) are stopped too
  Get-ListenerProcesses | Where-Object { $_.CommandLine -match [regex]::Escape($InstallDir) } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

  # --------------------------------------------------------------------------- 1. runtime
  Step 'Runtime'
  $ps51 = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  if (-not (Test-Path $ps51)) { throw "Windows PowerShell 5.1 not found at $ps51." }
  if (-not (Test-Path (Join-Path $env:SystemRoot 'System32\conhost.exe'))) { throw 'conhost.exe missing; the hidden-window launcher needs it.' }
  Add-Type -AssemblyName System.Drawing; Add-Type -AssemblyName System.Web; Add-Type -AssemblyName System.Windows.Forms
  $browsers = @('C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe', 'C:\Program Files\Microsoft\Edge\Application\msedge.exe',
                'C:\Program Files\Google\Chrome\Application\chrome.exe', 'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe')
  $browser = $browsers | Where-Object { Test-Path $_ } | Select-Object -First 1
  if (-not $browser) {
    Say 'No Edge/Chrome found for rendering - installing Microsoft Edge with winget.'
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if (-not $winget) { throw 'winget is not available. Install Microsoft Edge or Google Chrome by hand, then re-run.' }
    & winget install --id Microsoft.Edge --exact --silent --accept-package-agreements --accept-source-agreements
    $browser = $browsers | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $browser) { throw 'Edge install did not produce msedge.exe. Install Edge or Chrome by hand, then re-run.' }
  }
  Say "Windows PowerShell $($PSVersionTable.PSVersion) / .NET System.Drawing OK / renderer $browser"

  # --------------------------------------------------------------------------- 2. helper files
  Step "Installing helper v2 to $InstallDir"
  New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
  foreach ($f in $HelperFiles) {
    $src = Join-Path $HelperSrc $f
    if (-not (Test-Path $src)) { throw "Kit is incomplete: helper\$f is missing." }
    Copy-Item $src (Join-Path $InstallDir $f) -Force
  }
  $settingsFile = Join-Path $InstallDir 'settings.json'
  $old = Read-Settings $settingsFile
  if ($old) {
    Say "Keeping existing settings.json (printer '$($old.printerName)', paper '$($old.paperName)', $($old.labelWidthIn) x $($old.labelHeightIn) in)."
    if ([int]$old.port -ne $Port) { Write-Settings $settingsFile $old.printerName $old.paperName $old.labelWidthIn $old.labelHeightIn $Port; Say "settings.json port set to $Port." }
  } else {
    $tpl = Read-Settings (Join-Path $HelperSrc 'settings.json')
    if (-not $tpl) { $tpl = [pscustomobject]@{ printerName = $ArkDefault; paperName = '4 x 6'; labelWidthIn = 6; labelHeightIn = 4 } }
    Write-Settings $settingsFile $tpl.printerName $tpl.paperName $tpl.labelWidthIn $tpl.labelHeightIn $Port
    Say "settings.json created with the shop defaults (edited below / in the setup page)."
  }
  Get-ChildItem $InstallDir -File | Unblock-File -ErrorAction SilentlyContinue
  if ($IsAdmin) {
    # the listener runs as the logged-on user: it must be able to write settings.json, btprint.log and work\ here
    $acl = Get-Acl $InstallDir
    $rule = New-Object Security.AccessControl.FileSystemAccessRule($User.Name, 'Modify', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
    $acl.AddAccessRule($rule); Set-Acl $InstallDir $acl
  }
  Say ("Installed: " + (($HelperFiles + 'settings.json') -join ', '))

  # --------------------------------------------------------------------------- 3. printer
  Step 'Label printer'
  $settings = Read-Settings $settingsFile
  $chosen = ''
  if ($PrinterName -and (Get-Printer -Name $PrinterName -ErrorAction SilentlyContinue)) {
    $chosen = $PrinterName; Say "Using installed printer '$chosen' (given on the command line)."
  }
  elseif ($PrinterKind -eq 'skip') { Say 'Printer step skipped (-PrinterKind skip): choose the printer in the setup page.' }
  else {
    $kind = $PrinterKind
    $arkInstalled = @(Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.DriverName -match 'Arkscan' -or $_.Name -match 'Arkscan' })
    if ($kind -eq 'auto') {
      if ($settings -and (Get-Printer -Name $settings.printerName -ErrorAction SilentlyContinue)) { $chosen = $settings.printerName; $kind = 'installed'; Say "Printer '$chosen' from settings.json is installed on this PC." }
      elseif ($arkInstalled.Count -gt 0) { $chosen = $arkInstalled[0].Name; $kind = 'installed'; Say "Found installed Arkscan printer '$chosen'." }
      elseif ($NoPrompt) { $kind = 'arkscan-network' }
      else {
        Say 'Which label printer does this PC use?'
        Say '  1  Arkscan 2054K on the shop Wi-Fi / network (the usual case)'
        Say '  2  Arkscan 2054K plugged in by USB'
        Say '  3  Another label printer - add it through Windows (Windows Update supplies the driver)'
        Say '  4  Skip for now - choose later in the setup page'
        switch (Ask 'Type 1, 2, 3 or 4 and press Enter [1]' '1') { '2' { $kind = 'arkscan-usb' } '3' { $kind = 'other' } '4' { $kind = 'none' } default { $kind = 'arkscan-network' } }
      }
    }
    if ($kind -eq 'arkscan-network') {
      if (-not $IsAdmin) { throw 'Installing the Arkscan driver and printer needs Administrator rights. Run Setup.cmd and click Yes at the Windows prompt.' }
      $ip = Ask "Arkscan IP address [$PrinterIP]" $PrinterIP
      if (-not (Test-Tcp $ip 9100)) { Warn "Nothing answers at ${ip}:9100 right now (printer off? other network?). Installing anyway." }
      $name = if ($PrinterName) { $PrinterName } else { $ArkDefault }
      Install-ArkscanDriver $DriverInf
      if (-not (Get-PrinterPort -Name $ip -ErrorAction SilentlyContinue)) { Say "Creating TCP/IP port $ip (RAW 9100)"; Add-PrinterPort -Name $ip -PrinterHostAddress $ip }
      if (Get-Printer -Name $name -ErrorAction SilentlyContinue) { Say "Printer '$name' already exists." } else { Add-Printer -Name $name -DriverName $DriverName -PortName $ip; Say "Printer '$name' created on port $ip." }
      $chosen = $name
    }
    elseif ($kind -eq 'arkscan-usb') {
      if (-not $IsAdmin) { throw 'Installing the Arkscan driver needs Administrator rights. Run Setup.cmd and click Yes at the Windows prompt.' }
      Install-ArkscanDriver $DriverInf
      $before = @(Get-Printer -ErrorAction SilentlyContinue | ForEach-Object { $_.Name })
      Say 'Plug the Arkscan into USB and switch it on. Waiting up to 5 minutes for Windows to add it...'
      $found = $null
      for ($i = 0; $i -lt 150 -and -not $found; $i++) {
        Start-Sleep -Seconds 2
        $found = Get-Printer -ErrorAction SilentlyContinue | Where-Object { $before -notcontains $_.Name -and ($_.DriverName -match 'Arkscan' -or $_.Name -match 'Arkscan') } | Select-Object -First 1
      }
      if ($found) { $chosen = $found.Name; Say "Windows added '$chosen'." } else { Warn 'No new Arkscan printer appeared. Plug it in later and pick it in the setup page.' }
    }
    elseif ($kind -eq 'other') {
      $before = @(Get-Printer -ErrorAction SilentlyContinue | ForEach-Object { $_.Name })
      Say 'Opening Windows Settings > Printers & scanners. Click "Add device" (or "Add manually"), let Windows'
      Say 'find and install your label printer, then come back here. Waiting up to 10 minutes for a new printer...'
      try { Start-Process 'ms-settings:printers' } catch { Warn 'Could not open Settings; open Settings > Bluetooth & devices > Printers & scanners yourself.' }
      $found = $null
      for ($i = 0; $i -lt 300 -and -not $found; $i++) {
        Start-Sleep -Seconds 2
        $found = Get-Printer -ErrorAction SilentlyContinue | Where-Object { $before -notcontains $_.Name } | Select-Object -First 1
      }
      if ($found) { $chosen = $found.Name; Say "New printer '$chosen' appeared." } else { Warn 'No new printer appeared. Add it later and pick it in the setup page.' }
    }
    elseif ($kind -eq 'none') { Say 'Choose the printer in the setup page.' }
  }
  if ($chosen) {
    # save the printer; pick a paper that matches the label size if the driver offers one
    $w = [double]$settings.labelWidthIn; $h = [double]$settings.labelHeightIn; $paper = [string]$settings.paperName
    try {
      $ps = New-Object System.Drawing.Printing.PrinterSettings; $ps.PrinterName = $chosen
      $sizes = @($ps.PaperSizes)
      if ($sizes.Count -gt 0 -and -not ($sizes | Where-Object { $_.PaperName -eq $paper })) {
        $m = $sizes | Where-Object { ([Math]::Abs($_.Width/100 - $w) -lt 0.11 -and [Math]::Abs($_.Height/100 - $h) -lt 0.11) -or ([Math]::Abs($_.Width/100 - $h) -lt 0.11 -and [Math]::Abs($_.Height/100 - $w) -lt 0.11) } | Select-Object -First 1
        if ($m) { $paper = $m.PaperName; Say "Paper '$paper' matches the $w x $h in label." } else { Warn "The driver of '$chosen' offers no paper of $w x $h in; pick one in the setup page." }
      }
    } catch {}
    Write-Settings $settingsFile $chosen $paper $w $h $Port
    Say "settings.json: printer '$chosen', paper '$paper', label $w x $h in."
  }
  # Windows printer defaults and the default printer are deliberately left alone.

  # --------------------------------------------------------------------------- 4. autostart
  Step 'Autostart (Startup shortcut + watchdog task)'
  New-Item -ItemType Directory -Force -Path $User.StartupFolder | Out-Null
  $lnkPath = Join-Path $User.StartupFolder $ShortcutName
  $ws  = New-Object -ComObject WScript.Shell
  $lnk = $ws.CreateShortcut($lnkPath)
  $lnk.TargetPath       = Join-Path $env:SystemRoot 'System32\conhost.exe'
  $lnk.Arguments        = $ServeArgs
  $lnk.WorkingDirectory = $InstallDir
  $lnk.WindowStyle      = 7
  $lnk.Save()
  Say "Startup shortcut : $lnkPath"
  $taskOk = $false
  try {
    $action    = New-ScheduledTaskAction -Execute 'conhost.exe' -Argument $ServeArgs
    $trigger   = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 30)
    $principal = New-ScheduledTaskPrincipal -UserId $User.Name -LogonType Interactive -RunLevel Limited
    $tsettings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 72)
    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $tsettings -Force | Out-Null
    $taskOk = $true
    Say "Scheduled task   : '$TaskName' every 30 min as $($User.Name)"
  } catch { Warn "Scheduled task not registered: $($_.Exception.Message)" }

  # --------------------------------------------------------------------------- 5. start it
  Step 'Starting the helper'
  if ($taskOk) { Start-ScheduledTask -TaskName $TaskName }
  else { Start-Process -FilePath 'conhost.exe' -ArgumentList $ServeArgs -WindowStyle Hidden }
  $up = $null
  for ($i = 0; $i -lt 20 -and -not $up; $i++) { Start-Sleep -Seconds 1; $up = Get-Url '/ping' 3 }
  if ($up -eq 'ok') { Say "Helper answers on http://localhost:$Port/ping" } else { Warn 'Helper did not answer within 20 s (the checkup below will report it).' }

  # --------------------------------------------------------------------------- 6. setup page
  if ($up -eq 'ok' -and -not $NoPrompt) {
    Step 'Printer settings page'
    Say "Opening http://localhost:$Port/setup in your browser."
    Say 'There: check the printer, the label size and the paper size, then click "Save and print test label".'
    try { Start-Process ("http://localhost:{0}/setup" -f $Port) } catch { Warn 'Could not open the browser; open the address yourself.' }
    [void](Ask 'When the test label looks right, come back here and press Enter to run the checkup' '')
  }
}

# =============================================================================== CHECKUP
Step 'CHECKUP'
$results = New-Object System.Collections.ArrayList
function Check($name, [bool]$ok, $fix, $detail = '') {
  $tag = if ($ok) { 'PASS' } else { 'FAIL' }
  $color = if ($ok) { 'Green' } else { 'Red' }
  Write-Host ("[{0}] {1}" -f $tag, $name) -ForegroundColor $color
  if ($detail) { Write-Host ("       {0}" -f $detail) }
  [void]$results.Add([pscustomobject]@{ Name = $name; Ok = $ok; Fix = $fix })
}
$helperPs1 = Join-Path $InstallDir 'btprint.ps1'
$helperLog = Join-Path $InstallDir 'btprint.log'
Check 'Helper files installed' ((Test-Path $helperPs1) -and (Test-Path (Join-Path $InstallDir 'label.html'))) "Run Setup.cmd again (it copies the files to $InstallDir)." $InstallDir

$ping = Get-Url '/ping'
Check "Port $Port answers (GET /ping -> ok)" ($ping -eq 'ok') "Log off and on (Startup shortcut), or run: schtasks /run /tn `"$TaskName`". Then read $helperLog." ("got: " + $(if ($null -eq $ping) { 'no answer' } else { $ping }))

$st = $null
$stRaw = Get-Url '/status' 30
if ($stRaw) { try { $st = $stRaw | ConvertFrom-Json } catch {} }
Check 'Helper v2 reports its status (GET /status)' ([bool]$st -and $st.version) "The helper on port $Port is not v2 (an old helper may still be running from another folder). Re-run Setup.cmd." $(if ($st) { "version $($st.version), printer '$($st.printer)', paper '$($st.paper)', label $($st.labelWidthIn) x $($st.labelHeightIn) in" } else { 'no JSON' })

if ($st) {
  Check "Printer '$($st.printer)' installed and reachable" ([bool]$st.printerInstalled -and [bool]$st.printerReachable) "Power the printer on and check its network / USB cable. If it is not installed, run Setup.cmd again or add it in Windows, then choose it at http://localhost:$Port/setup." $st.printerDetail
  Check "Paper '$($st.paper)' offered by the driver" ([bool]$st.paperOffered) "Open http://localhost:$Port/setup and pick a paper size from the list." $(if ($st.paperOffered -and -not $st.paperMatchesLabel) { "offered, but its size does not match the $($st.labelWidthIn) x $($st.labelHeightIn) in label - the label prints in the top-left corner" } else { '' })
} else {
  Check 'Printer installed and reachable' $false 'Fix the helper first (see above), then re-run with -CheckOnly.' 'not checked'
  Check 'Paper offered by the driver' $false 'Fix the helper first (see above), then re-run with -CheckOnly.' 'not checked'
}

if ($SkipTestPrint) { Write-Host '[SKIP] Test label (-SkipTestPrint)' -ForegroundColor Yellow }
elseif ($ping -ne 'ok') { Check 'Test label printed' $false 'Fix the helper first (see above), then re-run with -CheckOnly.' 'listener not answering, not attempted' }
else {
  $before = 0
  if (Test-Path $helperLog) { $before = @(Get-Content $helperLog -Encoding UTF8).Count }
  $qs = 'c=TEST&n=' + [Uri]::EscapeDataString("Setup check $env:COMPUTERNAME") + '&p=' + [Uri]::EscapeDataString((Get-Date -Format 'HH:mm')) + '&d=' + (Get-Date).DayOfWeek + '&x=' + [Uri]::EscapeDataString('Printed by Setup-PrintHelper.ps1 - throw away')
  [void](Get-Url "/print?$qs" 15)
  $printed = $false; $err = ''
  for ($i = 0; $i -lt 60 -and -not $printed -and -not $err; $i++) {
    Start-Sleep -Seconds 1
    if (Test-Path $helperLog) {
      $new = @(Get-Content $helperLog -Encoding UTF8) | Select-Object -Skip $before
      if ($new | Where-Object { $_ -match ' PRINTED to ' }) { $printed = $true }
      $e = $new | Where-Object { $_ -match ' ERROR ' } | Select-Object -First 1
      if ($e) { $err = $e }
    }
  }
  Check 'Test label printed (one label with CONTAINER "TEST" should come out)' $printed "Read $helperLog. Typical causes: printer off / wrong IP, no label stock, Edge missing (render), paper not offered by the driver." $(if ($printed) { 'log shows PRINTED' } elseif ($err) { $err } else { 'no PRINTED line in the log within 60 s' })
}

$lnk = Join-Path $User.StartupFolder $ShortcutName
Check "Startup shortcut present for $($User.Name)" (Test-Path $lnk) 'Run Setup.cmd again (step 4 writes the shortcut).' $lnk
$task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
Check "Scheduled task '$TaskName' registered" ([bool]($task -and $task.State -ne 'Disabled')) 'Run Setup.cmd again (step 4 registers the task).' $(if ($task) { "state=$($task.State)" } else { 'missing' })

Write-Host ''
$failed = @($results | Where-Object { -not $_.Ok })
if ($failed.Count -eq 0) {
  Write-Host 'ALL GOOD' -ForegroundColor Green
  Write-Host "Open the Bedikas Tefilin app on this PC and click Print label on a ticket."
  Write-Host "Printer settings any time: http://localhost:$Port/setup   Health: http://localhost:$Port/ping"
} else {
  Write-Host ("{0} check(s) FAILED:" -f $failed.Count) -ForegroundColor Red
  foreach ($f in $failed) { Write-Host (" - {0}" -f $f.Name) -ForegroundColor Red; Write-Host ("     fix: {0}" -f $f.Fix) }
  Write-Host "After fixing, run Setup.cmd again, or:  powershell -ExecutionPolicy Bypass -File Setup-PrintHelper.ps1 -CheckOnly"
  $ExitCode = 1
}
}
catch {
  Write-Host ''
  Write-Host ("SETUP STOPPED: " + $_.Exception.Message) -ForegroundColor Red
  Write-Host ($_.InvocationInfo.PositionMessage)
  $ExitCode = 2
}
finally {
  if ($Payload -and (Test-Path $Payload)) { Remove-Item $Payload -Recurse -Force -ErrorAction SilentlyContinue }
  if (-not $NoPrompt) { [void](Read-Host 'Press Enter to close this window') }
}
exit $ExitCode
