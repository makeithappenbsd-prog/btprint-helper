BT Print helper v2 - one-click label printing for the Bedikas Tefilin app
=========================================================================
This folder (normally C:\PrintHelper) holds the small Windows PowerShell program that prints the
labels when someone clicks "Print label" in the Zoho Creator app "Bedikas Tefilin".

  btprint.ps1     the helper (Windows PowerShell 5.1, nothing else to install)
  label.html      the label layout (designed for the 4 x 6 label, 6 in wide x 4 in tall, scaled to the size in settings.json)
  settings.json   THIS PC's choices: printerName, paperName, labelWidthIn, labelHeightIn, port
  btprint.log     one line per request / print / error
  work\           the last 40 rendered labels (html + png), for troubleshooting

How a label gets printed
  1. The app opens  http://localhost:8765/print-close?c=<container>&n=<name>&p=<phone>&d=<day>&x=<notes>
  2. The helper fills label.html, renders it with the built-in headless Microsoft Edge to a picture at
     203 dpi, and prints that picture to the printer in settings.json on the paper in settings.json,
     per job only. Windows printer defaults and the Windows default printer are never changed.

Pages the helper serves on this PC (open in any browser)
  http://localhost:8765/setup      choose printer, label size and paper size; print a test label; Save
                                   (lists every printer on this PC right now; "Refresh printer list" after plugging one in)
  http://localhost:8765/printers   JSON list of the printers installed on this PC
  http://localhost:8765/status     JSON health: version, printer, paper, size, printer reachable
  http://localhost:8765/preview?.. the label at this PC's size, for Ctrl+P (linked from the app)
  http://localhost:8765/ping       "ok" when the helper is running
  http://localhost:8765/test?..    renders only, prints nothing (for troubleshooting)

It starts by itself
  Startup-folder shortcut "BT Print Server.lnk" starts it at every logon, and the Task Scheduler task
  "BT Print Server watchdog" restarts it every 30 minutes if it is gone. Both run it hidden
  (conhost.exe --headless powershell.exe ... btprint.ps1 -ServeHidden).
  Start it by hand:  schtasks /run /tn "BT Print Server watchdog"

Label size
  settings.json is read for every print. Change it on the /setup page (or edit the file). Sizes are named like the stock ("4 x 6") and the long side always prints across. The 6 x 4
  layout is scaled proportionally to the chosen size and centred, so a 4 x 3 label gets the same look.

To remove
  delete the Startup shortcut, delete the scheduled task, end the hidden powershell.exe that runs
  btprint.ps1 -Serve (Task Manager > Details), delete this folder.
