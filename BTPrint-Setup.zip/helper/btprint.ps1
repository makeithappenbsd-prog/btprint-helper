# BT label one-click print  -  helper v2
#   btprint.ps1 -Serve [-Port 8766]          run the localhost listener (the Startup shortcut / watchdog use -ServeHidden)
#   btprint.ps1 -Url "<url>" [-NoPrint]      print one label from a http://localhost/print?... URL
#
# URL contract (unchanged from v1):   /print?c=&n=&p=&d=&x=    /print-close?...    /test?...  (render only)    /ping -> "ok"
# New in v2.1.0 (2026-11-08): optional app overrides on /print, /print-close, /preview (from the app's Settings; blank = this PC's settings.json):
#                                     ls=4x6|3x4|...|full (full = Letter page)  pr=printer  pp=paper  cp=copies (1-5)  hp=0 / hd=0 / hn=0 hide phone / day / notes
# New in v2.1.2 (2026-11-10): the knot boxes (kesher mem [ ] dalet [ ]) are no longer in the container box; they print as their own row in the item list,
#                                     right under every item that contains sgira (also combined items such as sgira vehachnasa), and nowhere else.
# New in v2.1.1 (2026-11-09): /setup lists every printer Windows has right now (with a quick status) and a Refresh printer list button;
#                                     /printers  JSON list of the printers installed on this PC
# New in v2:                          /setup   printer + paper + label size chooser, test label, writes settings.json
#                                     /preview?c=&n=&p=&d=&x=   the label at this PC's size with a matching @page (Ctrl+P)
#                                     /status  JSON: version, printer, paper, size, reachable
# settings.json (beside this script) is read for EVERY print: printerName, paperName, labelWidthIn, labelHeightIn, port, version.
# If it is missing or unreadable the 2026-10-08 production values are used (Arkscan 2054K_WF, paper "4 x 6", label 4 x 6, 8765).
# Label sizes are named like the stock ("4 x 6"); the layout always prints with the long side across
# (labelWidthIn = long side, labelHeightIn = short side), so "4 x 6" = 6 in wide x 4 in tall.
param([string]$Url = '', [switch]$NoPrint, [switch]$Serve, [switch]$ServeHidden, [int]$Port = 0)
$ErrorActionPreference = 'Stop'
$HelperVersion = '2.1.2'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$log = Join-Path $dir 'btprint.log'
$settingsPath = Join-Path $dir 'settings.json'
$Defaults = @{ printerName = 'Arkscan 2054K_WF'; paperName = '4 x 6'; labelWidthIn = 6.0; labelHeightIn = 4.0; port = 8765 }
$Inv = [Globalization.CultureInfo]::InvariantCulture

function Log($m) {
  $line = "{0} {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m
  for ($i = 0; $i -lt 5; $i++) { try { Add-Content -Path $log -Value $line -Encoding UTF8; return } catch { Start-Sleep -Milliseconds 200 } }
}
function HtmlEsc($s) { [System.Web.HttpUtility]::HtmlEncode([string]$s) }
# v2.0.5 (22-Oct-2026): an item containing the closing-and-insertion phrase (BoxWord1 + BoxWord2 below) prints an empty check box between the two words (after the first one).
# The Hebrew is written as \u escapes because this file is saved without a BOM and Windows PowerShell 5.1 would read literal Hebrew as ANSI.
$BoxWord1 = [regex]::Unescape('\u05E1\u05D2\u05D9\u05E8\u05D4')         # samekh-gimel-yod-resh-he (sgira)
$BoxWord2 = [regex]::Unescape('\u05D5\u05D4\u05DB\u05E0\u05E1\u05D4')    # vav-he-kaf-nun-samekh-he (vehachnasa)
$BoxPattern = [regex]::Escape($BoxWord1) + '\s+' + [regex]::Escape($BoxWord2)
$BoxRepl = $BoxWord1 + ' <span class="bt-box"></span> ' + $BoxWord2   # v2.0.6: one box between the two words only (owner, 22-Oct)
function Add-ItemBoxes($escapedHtml) { [regex]::Replace([string]$escapedHtml, $BoxPattern, $BoxRepl) }
# v2.1.2 (10-Nov-2026): knot row "kesher  mem [ ]  dalet [ ]" (moved out of the container box), only under items containing BoxWord1 (sgira)
$KnotHtml = [regex]::Unescape('\u05E7\u05E9\u05E8') + '&nbsp;&nbsp;&nbsp;' + [regex]::Unescape('\u05DE') + '<span class="bt-box"></span>&nbsp;&nbsp;&nbsp;' + [regex]::Unescape('\u05D3') + '<span class="bt-box"></span>'
function Test-HasSgira($s) { ([string]$s).Contains($BoxWord1) }
function UrlEnc($s)  { [Uri]::EscapeDataString([string]$s) }
function Num($d)     { ([double]$d).ToString('0.####', $Inv) }
function SizeName([double]$w, [double]$h) { (Num ([Math]::Min($w, $h))) + ' x ' + (Num ([Math]::Max($w, $h))) }   # stock name: short x long
function Parse-Size([string]$a, [string]$b) {
  # two numbers in any order -> @(width, height) with the long side as the width (the layout is landscape)
  $x = [double]::Parse($a.Trim(), $Inv); $y = [double]::Parse($b.Trim(), $Inv)
  return @([Math]::Max($x, $y), [Math]::Min($x, $y))
}
Add-Type -AssemblyName System.Web
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms

# ----------------------------------------------------------------------------- settings
function Get-Settings {
  $s = @{}
  foreach ($k in $Defaults.Keys) { $s[$k] = $Defaults[$k] }
  $s.defaultsInUse = $true
  if (Test-Path $settingsPath) {
    try {
      $j = Get-Content $settingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
      foreach ($k in 'printerName', 'paperName', 'labelWidthIn', 'labelHeightIn', 'port') {
        $prop = $j.PSObject.Properties[$k]
        if ($prop -and $null -ne $prop.Value -and ("" + $prop.Value) -ne '') { $s[$k] = $prop.Value }
      }
      $s.defaultsInUse = $false
    } catch { Log "SETTINGS unreadable ($($_.Exception.Message)) - using built-in defaults" }
  }
  try { $s.labelWidthIn = [double]::Parse(("" + $s.labelWidthIn), $Inv) } catch { $s.labelWidthIn = 6.0 }
  try { $s.labelHeightIn = [double]::Parse(("" + $s.labelHeightIn), $Inv) } catch { $s.labelHeightIn = 4.0 }
  try { $s.port = [int]$s.port } catch { $s.port = 8765 }
  if ($s.labelWidthIn -lt 0.5 -or $s.labelWidthIn -gt 20 -or $s.labelHeightIn -lt 0.5 -or $s.labelHeightIn -gt 20) { $s.labelWidthIn = 6.0; $s.labelHeightIn = 4.0 }
  if ($s.labelHeightIn -gt $s.labelWidthIn) { $t = $s.labelWidthIn; $s.labelWidthIn = $s.labelHeightIn; $s.labelHeightIn = $t }   # long side across
  return $s
}
function Save-Settings($s) {
  $o = [ordered]@{ version = $HelperVersion; printerName = [string]$s.printerName; paperName = [string]$s.paperName
                   labelWidthIn = [double]$s.labelWidthIn; labelHeightIn = [double]$s.labelHeightIn; port = [int]$s.port }
  [IO.File]::WriteAllText($settingsPath, ($o | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
  Log ("SETTINGS saved printer=[{0}] paper=[{1}] size={2}x{3} port={4}" -f $o.printerName, $o.paperName, (Num $o.labelWidthIn), (Num $o.labelHeightIn), $o.port)
}

function Apply-AppOverrides($S, $kv) {
  # v2.1.0 (2026-11-08): label options sent by the app (Settings > Desk and printing). Each one is optional; anything missing keeps this PC's settings.json value.
  $S.fullPage = $false; $S.copies = 1; $S.drawOffsetIn = 0.0
  if (-not $kv) { return $S }
  $ls = ([string]$kv['ls']).Trim().ToLower()
  if ($ls -eq 'full') {
    # full page = US Letter, the 6 x 4 layout scaled up and printed across the page inside a 0.25 in margin (office printers cannot print to the edge)
    $S.fullPage = $true; $S.labelWidthIn = 10.5; $S.labelHeightIn = 8.0; $S.drawOffsetIn = 0.25
    if (-not ([string]$kv['pp']).Trim()) { $S.paperName = 'Letter' }
  } elseif ($ls -match '^\s*([\d.]+)\s*x\s*([\d.]+)\s*$') {
    try { $w, $h = Parse-Size $Matches[1] $Matches[2]; if ($w -ge 0.5 -and $w -le 20 -and $h -ge 0.5 -and $h -le 20) { $S.labelWidthIn = $w; $S.labelHeightIn = $h } } catch {}
  }
  $pr = ([string]$kv['pr']).Trim(); if ($pr) { $S.printerName = $pr }
  $pp = ([string]$kv['pp']).Trim(); if ($pp) { $S.paperName = $pp }
  $cp = 1; try { $cp = [int]([string]$kv['cp']) } catch {}; if ($cp -ge 1 -and $cp -le 5) { $S.copies = $cp }
  return $S
}
function Apply-HiddenFields($f) {
  # v2.1.0: hp=0 / hd=0 / hn=0 leave PHONE / DAY / NOTES empty on the label
  if (-not $f.kv) { return $f }
  if ([string]$f.kv['hp'] -eq '0') { $f.p = '' }
  if ([string]$f.kv['hd'] -eq '0') { $f.d = '' }
  if ([string]$f.kv['hn'] -eq '0') { $f.x = '' }
  return $f
}

# ----------------------------------------------------------------------------- printer info
function Get-InstalledPrinters { @([System.Drawing.Printing.PrinterSettings]::InstalledPrinters | ForEach-Object { [string]$_ }) }
function Get-PaperSizes($printerName) {
  # paper sizes the printer's driver offers (System.Drawing PrinterSettings.PaperSizes), in inches
  $out = @()
  if (-not $printerName) { return $out }
  try {
    $ps = New-Object System.Drawing.Printing.PrinterSettings; $ps.PrinterName = $printerName
    if (-not $ps.IsValid) { return $out }
    foreach ($p in $ps.PaperSizes) { $out += [pscustomobject]@{ Name = $p.PaperName; W = [Math]::Round($p.Width / 100.0, 2); H = [Math]::Round($p.Height / 100.0, 2) } }
  } catch {}
  return $out
}
function Get-PrinterList {
  # v2.1.1: every printer Windows has right now, with a quick status (no network test, so the page stays fast)
  $out = @()
  $names = Get-InstalledPrinters
  $info = @{}
  try { foreach ($w in @(Get-CimInstance Win32_Printer -ErrorAction Stop)) { $info[[string]$w.Name] = $w } } catch {}
  foreach ($n in $names) {
    $w = $info[$n]; $st = 'ready'; $port = ''; $isDef = $false
    if ($w) {
      $port = [string]$w.PortName; $isDef = [bool]$w.Default
      if ($w.WorkOffline) { $st = 'offline' }
      elseif ($w.PrinterStatus -eq 7) { $st = 'offline or not connected' }
      elseif ($w.PrinterStatus -eq 6) { $st = 'stopped' }
    }
    $virtual = $n -match '(?i)(PDF|XPS|OneNote|Fax|Send To)'
    $out += [pscustomobject]@{ Name = $n; Status = $st; Port = $port; WindowsDefault = $isDef; Virtual = [bool]$virtual }
  }
  return $out
}
function Test-Printer($printerName) {
  # installed? reachable? (network printers: TCP connect to the RAW port; others: status Normal and not "work offline")
  $r = @{ installed = $false; reachable = $false; detail = 'not installed'; port = ''; driver = '' }
  if (-not $printerName) { return $r }
  $p = $null
  try { $p = Get-Printer -Name $printerName -ErrorAction Stop } catch {}
  if (-not $p) { return $r }
  $r.installed = $true; $r.port = [string]$p.PortName; $r.driver = [string]$p.DriverName
  $offline = $false
  try { $w = Get-CimInstance Win32_Printer -Filter ("Name='" + $printerName.Replace("'", "''") + "'"); if ($w) { $offline = [bool]$w.WorkOffline } } catch {}
  $pp = $null
  try { $pp = Get-PrinterPort -Name $p.PortName -ErrorAction Stop } catch {}
  if ($pp -and $pp.PrinterHostAddress) {
    $tcpPort = 9100; if ($pp.PortNumber) { $tcpPort = [int]$pp.PortNumber }
    $ok = $false
    try { $c = New-Object Net.Sockets.TcpClient; $ar = $c.BeginConnect($pp.PrinterHostAddress, $tcpPort, $null, $null); $ok = $ar.AsyncWaitHandle.WaitOne(2500) -and $c.Connected; $c.Close() } catch {}
    $r.reachable = $ok -and -not $offline
    $r.detail = "network {0}:{1} {2}" -f $pp.PrinterHostAddress, $tcpPort, $(if ($ok) { 'answers' } else { 'no answer' })
  } else {
    $r.reachable = ($p.PrinterStatus -eq 'Normal') -and -not $offline
    $r.detail = "port {0} status {1}" -f $p.PortName, $p.PrinterStatus
  }
  if ($offline) { $r.detail += ' (Windows: work offline)' }
  return $r
}

# ----------------------------------------------------------------------------- label html / render / print
function Build-LabelHtml($cont, $name, $phone, $day, $notes, [double]$w, [double]$h, [string]$extraHead = '', [string]$extraBody = '') {
  $tpl = [IO.File]::ReadAllText((Join-Path $dir 'label.html'), [Text.Encoding]::UTF8)
  # v2.0.7 (22-Oct-2026): a US country code in front of a 10-digit number ("+1-3477032617", "+1 347...", "1-347...") is dropped on the label; it does not fit the PHONE cell.
  $phone = [regex]::Replace([string]$phone, '^\s*\+?1[\s\-\.]*(?=\(?(?:\d[\s\-\.\(\)]*){10}\s*$)', '')
  $notesBlock = ''
  if (([string]$notes).Trim() -ne '') { $notesBlock = '<div class="bt-notes-txt">' + (HtmlEsc $notes) + '</div>' }
  $scale = [Math]::Min($w / 6.0, $h / 4.0)              # the layout is designed at 6 x 4 in; scale it proportionally
  $offx = ($w - 6.0 * $scale) / 2.0; $offy = ($h - 4.0 * $scale) / 2.0
  # v2.0.3 (16-Oct-2026): the customer on the first line, then EVERY item on its own line with a leading dash.
  # The app joins the items with ", " in the ticket name ("Customer - item1, item2 x3"); anything without " - " prints as before.
  $nameHtml = HtmlEsc $name
  $sepAt = ([string]$name).IndexOf(' - ')
  if ($sepAt -gt 0) {
      $custPart = ([string]$name).Substring(0, $sepAt)
      $itemPart = ([string]$name).Substring($sepAt + 3)
      $items = @($itemPart -split ', ' | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' })
      if ($items.Count -ge 1) {
          $liHtml = ($items | ForEach-Object { '<li>' + (Add-ItemBoxes (HtmlEsc $_)) + '</li>' + $(if (Test-HasSgira $_) { '<li class="bt-knot">' + $KnotHtml + '</li>' } else { '' }) }) -join ''
          $nameHtml = '<div class="bt-cust">' + (HtmlEsc $custPart) + '</div><ul class="bt-items">' + $liHtml + '</ul>'
      }
  }
  if ($nameHtml -notmatch 'bt-items' -and (Test-HasSgira $name)) { $nameHtml = $nameHtml + '<ul class="bt-items"><li class="bt-knot">' + $KnotHtml + '</li></ul>' }   # v2.1.2: name without an item list
  $html = $tpl.Replace('{{CONT}}', (HtmlEsc $cont)).Replace('{{NAME}}', $nameHtml).Replace('{{PHONE}}', (HtmlEsc $phone)).Replace('{{DAY}}', (HtmlEsc $day)).Replace('{{NOTES_BLOCK}}', $notesBlock)
  $html = $html.Replace('{{W}}', (Num $w) + 'in').Replace('{{H}}', (Num $h) + 'in').Replace('{{SCALE}}', (Num $scale)).Replace('{{OFFX}}', (Num $offx) + 'in').Replace('{{OFFY}}', (Num $offy) + 'in')
  $html = $html.Replace('{{EXTRA_HEAD}}', $extraHead).Replace('{{EXTRA_BODY}}', $extraBody)
  return $html
}
function Parse-Fields([string]$RequestUrl) {
  $q = $RequestUrl
  if ($q -match '\?') { $q = $q.Substring($q.IndexOf('?') + 1) } else { $q = '' }
  $q = $q.TrimEnd('/')
  $kv = [System.Web.HttpUtility]::ParseQueryString($q)
  return @{ c = [string]$kv['c']; n = [string]$kv['n']; p = [string]$kv['p']; d = [string]$kv['d']; x = [string]$kv['x']; kv = $kv }
}

function Invoke-LabelPrint([string]$RequestUrl, [bool]$RenderOnly) {
  Log "START url=$RequestUrl renderOnly=$RenderOnly"
  if ($RequestUrl -match '^(/|https?://[^/]*/)test(-close)?(\?|/|$)') { $RenderOnly = $true }
  $f = Apply-HiddenFields (Parse-Fields $RequestUrl)
  $cont = $f.c; $name = $f.n; $phone = $f.p; $day = $f.d; $notes = $f.x
  $S = Apply-AppOverrides (Get-Settings) $f.kv
  $w = $S.labelWidthIn; $h = $S.labelHeightIn
  Log ("FIELDS cont=[{0}] name=[{1}] phone=[{2}] day=[{3}] notesLen={4} | size {5}x{6} printer=[{7}] paper=[{8}] copies={10} fullPage={11}{9}" -f $cont, $name, $phone, $day, $notes.Length, (Num $w), (Num $h), $S.printerName, $S.paperName, $(if ($S.defaultsInUse) { ' (built-in defaults)' } else { '' }), $S.copies, $S.fullPage)

  $html = Build-LabelHtml $cont $name $phone $day $notes $w $h
  $work = Join-Path $dir 'work'
  if (-not (Test-Path $work)) { New-Item -ItemType Directory -Path $work | Out-Null }
  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
  $htmlPath = Join-Path $work "label-$stamp.html"
  $pngPath  = Join-Path $work "label-$stamp.png"
  [IO.File]::WriteAllText($htmlPath, $html, (New-Object Text.UTF8Encoding($true)))

  # render with headless Edge/Chrome at 203 dpi: window = W x H in CSS px (96/in), device scale 203/96
  $browser = @('C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
               'C:\Program Files\Microsoft\Edge\Application\msedge.exe',
               'C:\Program Files\Google\Chrome\Application\chrome.exe',
               'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe') | Where-Object { Test-Path $_ } | Select-Object -First 1
  if (-not $browser) { throw 'No Edge or Chrome found for rendering.' }
  $profile = Join-Path $dir 'render-profile'
  $pxW = [int][Math]::Round($w * 96); $pxH = [int][Math]::Round($h * 96)
  $argList = @('--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', '--no-default-browser-check', '--disable-extensions',
            ('"--user-data-dir=' + $profile + '"'), ('--window-size={0},{1}' -f $pxW, $pxH), '--force-device-scale-factor=2.114583',
            ('"--screenshot=' + $pngPath + '"'), ('"file:///' + $htmlPath.Replace('\','/') + '"'))
  $p = Start-Process -FilePath $browser -ArgumentList $argList -PassThru -WindowStyle Hidden
  if (-not $p.WaitForExit(45000)) { $p.Kill(); throw 'Renderer timed out.' }
  if (-not (Test-Path $pngPath)) { throw "Renderer produced no image (exit $($p.ExitCode))." }
  $img = [System.Drawing.Image]::FromFile($pngPath)
  Log ("RENDERED {0}x{1}" -f $img.Width, $img.Height)
  if ($RenderOnly) { Log "RENDER-ONLY done -> $pngPath"; $img.Dispose(); return $pngPath }

  # print with per-job settings only; printer defaults are never touched
  $pd = New-Object System.Drawing.Printing.PrintDocument
  $pd.PrinterSettings.PrinterName = $S.printerName
  if (-not $pd.PrinterSettings.IsValid) { throw "Printer '$($S.printerName)' not found. Open http://localhost:$ListenPort/setup to choose a printer." }
  $paper = $pd.PrinterSettings.PaperSizes | Where-Object { $_.PaperName -eq $S.paperName } | Select-Object -First 1
  if (-not $paper) { throw "Paper size '$($S.paperName)' is not offered by the driver of '$($S.printerName)'. Open http://localhost:$ListenPort/setup to choose one." }
  $pd.DefaultPageSettings.PaperSize = $paper
  # landscape when the label's orientation differs from the paper's own (e.g. 6 x 4 label on the "4 x 6" paper)
  $pd.DefaultPageSettings.Landscape = (($w -gt $h) -ne ($paper.Width -gt $paper.Height))
  $pd.PrinterSettings.Copies = [int16]$S.copies
  $pd.DefaultPageSettings.Margins = New-Object System.Drawing.Printing.Margins(0, 0, 0, 0)
  $pd.OriginAtMargins = $false
  $pd.DocumentName = "BT label $cont $name"
  $pd.PrintController = New-Object System.Drawing.Printing.StandardPrintController
  $script:btImg = $img; $script:btW = $w; $script:btH = $h; $script:btOff = [double]$S.drawOffsetIn
  $pd.add_PrintPage({
    param($sender, $e)
    $e.Graphics.PageUnit = [System.Drawing.GraphicsUnit]::Inch
    $e.Graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $e.Graphics.DrawImage($script:btImg, [single]$script:btOff, [single]$script:btOff, [single]$script:btW, [single]$script:btH)
    $e.HasMorePages = $false
  })
  $prevDefault = (Get-CimInstance Win32_Printer | Where-Object { $_.Default }).Name
  $pd.Print()
  $img.Dispose()
  Log ("PRINTED to {0} ({1} {2})" -f $S.printerName, $paper.PaperName, $(if ($pd.DefaultPageSettings.Landscape) { 'landscape' } else { 'portrait' }))
  # Windows' "last used printer becomes default" can flip the default; put it back so other apps are unaffected.
  if ($prevDefault -and $prevDefault -ne $S.printerName) {
    Start-Sleep -Milliseconds 1500
    $nowDefault = (Get-CimInstance Win32_Printer | Where-Object { $_.Default }).Name
    if ($nowDefault -ne $prevDefault) {
      $prev = Get-CimInstance Win32_Printer | Where-Object { $_.Name -eq $prevDefault }
      if ($prev) { Invoke-CimMethod -InputObject $prev -MethodName SetDefaultPrinter | Out-Null; Log "DEFAULT restored to $prevDefault" }
    }
  }
  Get-ChildItem $work -File | Sort-Object LastWriteTime -Descending | Select-Object -Skip 40 | Remove-Item -Force -ErrorAction SilentlyContinue
  return $pngPath
}

function Show-Err($msg) {
  try { [System.Windows.Forms.MessageBox]::Show("Label did not print:`n`n$msg`n`nLog: $log", 'BT Print', 'OK', 'Error') | Out-Null } catch {}
}

# ----------------------------------------------------------------------------- v2 pages
$SizePresets = @('4 x 6', '3 x 4', '2 x 4', '2 x 3', '1.25 x 2.25')
$PageCss = 'body{font-family:Arial,Helvetica,sans-serif;color:#1A2530;background:#F4F6F8;margin:0;padding:24px}.card{background:#fff;border:1px solid #D9DEE3;border-radius:10px;padding:20px 24px;max-width:760px;margin:0 auto 16px}h1{font-size:22px;margin:0 0 4px}h2{font-size:15px;margin:18px 0 8px}label{display:block;font-weight:700;font-size:13px;margin:12px 0 4px}select,input[type=text],input[type=number]{font-size:15px;padding:7px 9px;border:1px solid #B9C2CB;border-radius:6px;min-width:260px}.btn{display:inline-block;border-radius:8px;padding:10px 18px;font-size:15px;font-weight:700;border:1px solid #1E7B34;background:#1E7B34;color:#fff;cursor:pointer;text-decoration:none;margin:14px 10px 0 0}.btn.alt{background:#2A5C8A;border-color:#2A5C8A}.btn.grey{background:#fff;color:#1A2530;border-color:#B9C2CB}.ok{color:#1E7B34;font-weight:700}.bad{color:#B3261E;font-weight:700}.hint{font-size:13px;color:#51606E}.msg{background:#E8F5EC;border:1px solid #1E7B34;border-radius:8px;padding:10px 14px;margin:0 0 14px;font-weight:700}.warn{background:#FFF4E5;border-color:#C77700}code{background:#EEF1F4;padding:1px 5px;border-radius:4px}table{border-collapse:collapse;font-size:14px}td{padding:3px 12px 3px 0;vertical-align:top}'

function Get-SetupPage($kv, [string]$message, [bool]$isWarn) {
  $S = Get-Settings
  $printers = Get-InstalledPrinters
  $selPrinter = [string]$kv['printer']; if (-not $selPrinter) { $selPrinter = $S.printerName }
  $w = $S.labelWidthIn; $h = $S.labelHeightIn
  $sizeSel = [string]$kv['size']
  if ($sizeSel -and $sizeSel -ne 'custom' -and $sizeSel -match '^\s*([\d.]+)\s*x\s*([\d.]+)\s*$') { $w, $h = Parse-Size $Matches[1] $Matches[2] }
  elseif ($sizeSel -eq 'custom' -and $kv['w'] -and $kv['h']) { try { $w, $h = Parse-Size $kv['w'] $kv['h'] } catch {} }
  $curSize = SizeName $w $h
  $isPreset = $SizePresets -contains $curSize
  $papers = Get-PaperSizes $selPrinter
  $selPaper = [string]$kv['paper']; if (-not $selPaper) { $selPaper = $S.paperName }
  if ($papers.Count -gt 0 -and -not ($papers | Where-Object { $_.Name -eq $selPaper })) {
    # saved paper not offered by this printer: preselect the one matching the label size, if any
    $m = $papers | Where-Object { ([Math]::Abs($_.W - $w) -lt 0.11 -and [Math]::Abs($_.H - $h) -lt 0.11) -or ([Math]::Abs($_.W - $h) -lt 0.11 -and [Math]::Abs($_.H - $w) -lt 0.11) } | Select-Object -First 1
    if ($m) { $selPaper = $m.Name }
  }
  $pt = Test-Printer $selPrinter
  $sb = New-Object Text.StringBuilder
  [void]$sb.Append("<!doctype html><html><head><meta charset='utf-8'><title>BT Print - printer settings on this computer</title><style>$PageCss</style></head><body>")
  [void]$sb.Append("<div class='card'><h1>Label printing on this computer</h1><div class='hint'>BT Print helper v$HelperVersion on $(HtmlEsc $env:COMPUTERNAME), port $ListenPort. These settings are only used by the Bedikas Tefilin label button; Windows printer defaults are never changed.</div></div>")
  if ($message) { [void]$sb.Append("<div class='card'><div class='msg" + $(if ($isWarn) { ' warn' } else { '' }) + "'>" + (HtmlEsc $message) + "</div></div>") }
  [void]$sb.Append("<div class='card'><form method='get' action='/setup'>")
  [void]$sb.Append("<label for='printer'>Label printer</label><select name='printer' id='printer' onchange='this.form.submit()'>")
  if ($printers -notcontains $selPrinter -and $selPrinter) { [void]$sb.Append("<option value='" + (HtmlEsc $selPrinter) + "' selected>" + (HtmlEsc $selPrinter) + " (not installed on this PC)</option>") }
  foreach ($pr in $printers) { [void]$sb.Append("<option value='" + (HtmlEsc $pr) + "'" + $(if ($pr -eq $selPrinter) { ' selected' } else { '' }) + ">" + (HtmlEsc $pr) + "</option>") }
  [void]$sb.Append("</select> <button class='btn grey' type='submit' name='action' value='refresh' style='margin-top:0;padding:7px 12px;font-size:13px'>Refresh printer list</button>")
  [void]$sb.Append("<div class='hint' style='margin-top:6px'>Just plugged in or added a printer? Click <b>Refresh printer list</b>. The list below is what Windows has on this computer right now.</div>")
  [void]$sb.Append("<div class='hint' style='margin-top:6px'>Printer check: " + $(if ($pt.reachable) { "<span class='ok'>reachable</span>" } elseif ($pt.installed) { "<span class='bad'>installed but not reachable</span>" } else { "<span class='bad'>not installed</span>" }) + " &middot; " + (HtmlEsc $pt.detail) + $(if ($pt.driver) { " &middot; driver " + (HtmlEsc $pt.driver) } else { '' }) + "</div>")
  [void]$sb.Append("<label for='size'>Label size (inches, as the label stock is named; the long side always prints across)</label><select name='size' id='size' onchange='this.form.submit()'>")
  foreach ($sz in $SizePresets) { [void]$sb.Append("<option value='" + $sz + "'" + $(if ($sz -eq $curSize) { ' selected' } else { '' }) + ">" + $sz + "</option>") }
  [void]$sb.Append("<option value='custom'" + $(if (-not $isPreset) { ' selected' } else { '' }) + ">custom...</option></select>")
  [void]$sb.Append(" <span class='hint'>custom: </span><input type='number' step='0.01' min='0.5' max='20' name='w' value='" + (Num ([Math]::Min($w, $h))) + "' style='min-width:70px;width:80px'> x <input type='number' step='0.01' min='0.5' max='20' name='h' value='" + (Num ([Math]::Max($w, $h))) + "' style='min-width:70px;width:80px'> in <span class='hint'>(prints " + (Num $w) + " wide x " + (Num $h) + " tall)</span>")
  [void]$sb.Append("<label for='paper'>Paper size (as the printer driver calls it)</label><select name='paper' id='paper'>")
  if ($papers.Count -eq 0) { [void]$sb.Append("<option value=''>(no paper sizes - printer not installed?)</option>") }
  foreach ($pa in $papers) {
    $match = ([Math]::Abs($pa.W - $w) -lt 0.11 -and [Math]::Abs($pa.H - $h) -lt 0.11) -or ([Math]::Abs($pa.W - $h) -lt 0.11 -and [Math]::Abs($pa.H - $w) -lt 0.11)
    [void]$sb.Append("<option value='" + (HtmlEsc $pa.Name) + "'" + $(if ($pa.Name -eq $selPaper) { ' selected' } else { '' }) + ">" + (HtmlEsc $pa.Name) + " &nbsp;(" + (Num $pa.W) + " x " + (Num $pa.H) + " in)" + $(if ($match) { ' - matches label' } else { '' }) + "</option>")
  }
  [void]$sb.Append("</select><div class='hint' style='margin-top:6px'>Pick the paper whose size matches the label (either orientation). The helper turns the page to landscape by itself when needed.</div>")
  [void]$sb.Append("<div><button class='btn' type='submit' name='action' value='save'>Save</button><button class='btn alt' type='submit' name='action' value='test'>Save and print test label</button>")
  [void]$sb.Append("<a class='btn grey' href='/preview?c=12&n=" + (UrlEnc 'Preview Sample') + "&p=845-555-0100&d=Tuesday&x=" + (UrlEnc 'Sample notes line') + "' target='_blank'>Preview a sample</a></div>")
  [void]$sb.Append("</form></div>")
  # v2.1.1: all printers on this computer now, each with a Use this one link
  $plist = Get-PrinterList
  [void]$sb.Append("<div class='card'><h2>Printers on this computer now (" + $plist.Count + ")</h2>")
  if ($plist.Count -eq 0) { [void]$sb.Append("<div class='bad'>Windows has no printers. Add one in Windows Settings &gt; Printers &amp; scanners, then click Refresh printer list.</div>") }
  else {
    [void]$sb.Append("<table><tr><td><b>Printer</b></td><td><b>Status</b></td><td><b>Port</b></td><td></td></tr>")
    foreach ($pi in $plist) {
      $stHtml = if ($pi.Status -eq 'ready') { "<span class='ok'>ready</span>" } else { "<span class='bad'>" + (HtmlEsc $pi.Status) + "</span>" }
      $tags = @(); if ($pi.Name -eq $S.printerName) { $tags += 'saved for labels' }; if ($pi.WindowsDefault) { $tags += 'Windows default' }; if ($pi.Virtual) { $tags += 'not a real printer' }
      $tagHtml = if ($tags.Count) { " <span class='hint'>(" + (HtmlEsc ($tags -join ', ')) + ")</span>" } else { '' }
      [void]$sb.Append("<tr><td>" + (HtmlEsc $pi.Name) + $tagHtml + "</td><td>" + $stHtml + "</td><td class='hint'>" + (HtmlEsc $pi.Port) + "</td><td><a href='/setup?printer=" + (HtmlEsc (UrlEnc $pi.Name)) + "'>Use this one</a></td></tr>")
    }
    [void]$sb.Append("</table><div class='hint' style='margin-top:8px'>After <b>Use this one</b>, check the paper size above and click <b>Save</b>.</div>")
  }
  [void]$sb.Append("</div>")
  [void]$sb.Append("<div class='card'><h2>Saved settings (settings.json)</h2><table><tr><td>Printer</td><td><b>" + (HtmlEsc $S.printerName) + "</b></td></tr><tr><td>Paper</td><td><b>" + (HtmlEsc $S.paperName) + "</b></td></tr><tr><td>Label size</td><td><b>" + (SizeName $S.labelWidthIn $S.labelHeightIn) + " in</b> (prints " + (Num $S.labelWidthIn) + " wide x " + (Num $S.labelHeightIn) + " tall)</td></tr><tr><td>File</td><td><code>" + (HtmlEsc $settingsPath) + "</code>" + $(if ($S.defaultsInUse) { " <span class='bad'>missing - built-in defaults in use</span>" } else { '' }) + "</td></tr><tr><td>Log</td><td><code>" + (HtmlEsc $log) + "</code></td></tr></table>")
  [void]$sb.Append("<div class='hint' style='margin-top:10px'>Health: <a href='/ping'>/ping</a> &middot; <a href='/status'>/status</a></div></div></body></html>")
  return $sb.ToString()
}

function Get-StatusJson {
  $S = Get-Settings
  $pt = Test-Printer $S.printerName
  $papers = Get-PaperSizes $S.printerName
  $paper = $papers | Where-Object { $_.Name -eq $S.paperName } | Select-Object -First 1
  $paperMatches = $false
  if ($paper) { $paperMatches = ([Math]::Abs($paper.W - $S.labelWidthIn) -lt 0.11 -and [Math]::Abs($paper.H - $S.labelHeightIn) -lt 0.11) -or ([Math]::Abs($paper.W - $S.labelHeightIn) -lt 0.11 -and [Math]::Abs($paper.H - $S.labelWidthIn) -lt 0.11) }
  $o = [ordered]@{
    version = $HelperVersion; port = $ListenPort; computer = $env:COMPUTERNAME
    printer = [string]$S.printerName; paper = [string]$S.paperName
    labelSize = (SizeName $S.labelWidthIn $S.labelHeightIn); labelWidthIn = [double]$S.labelWidthIn; labelHeightIn = [double]$S.labelHeightIn
    printerInstalled = [bool]$pt.installed; printerReachable = [bool]$pt.reachable; printerDetail = [string]$pt.detail
    paperOffered = [bool]$paper; paperMatchesLabel = $paperMatches
    settingsFile = $settingsPath; defaultsInUse = [bool]$S.defaultsInUse; log = $log
  }
  return ($o | ConvertTo-Json)
}

function Get-PreviewPage([string]$path) {
  $f = Apply-HiddenFields (Parse-Fields $path)
  $S = Apply-AppOverrides (Get-Settings) $f.kv
  $extraHead = "@media screen { body { background:#F4F6F8; padding:16px; } .bt-page { box-shadow:0 2px 10px rgba(0,0,0,.18); border:1px dashed #999; margin:0 auto; } .bt-tools { font-family:Arial,Helvetica,sans-serif; max-width:900px; margin:0 auto 14px; display:flex; gap:12px; align-items:center; flex-wrap:wrap; font-size:13px; color:#1A2530 } .bt-tools a,.bt-tools button { display:inline-flex; align-items:center; border-radius:8px; padding:10px 16px; font-size:14px; font-weight:700; text-decoration:none; cursor:pointer; border:1px solid #2A5C8A; background:#2A5C8A; color:#fff } .bt-tools .bt-print { background:#1E7B34; border-color:#1E7B34; font-size:16px } } @media print { .bt-tools { display:none !important } body { background:#fff; padding:0 } .bt-page { box-shadow:none; border:none } }"
  $q = $path; if ($q -match '\?') { $q = $q.Substring($q.IndexOf('?')) } else { $q = '' }
  $extraBody = "<div class='bt-tools'><a class='bt-print' href='/print-close$q' target='_blank'>Print label</a><button type='button' onclick='window.print()'>Print with Ctrl+P...</button><span>Preview at <b>" + (SizeName $S.labelWidthIn $S.labelHeightIn) + " in</b> (this PC's settings, " + (Num $S.labelWidthIn) + " wide x " + (Num $S.labelHeightIn) + " tall). For Ctrl+P choose printer <b>" + (HtmlEsc $S.printerName) + "</b>, paper <b>" + (HtmlEsc $S.paperName) + "</b>, margins none, scale 100%. <a href='/setup' style='background:#fff;color:#1A2530;border-color:#B9C2CB'>Printer settings</a></span></div>"
  return Build-LabelHtml $f.c $f.n $f.p $f.d $f.x $S.labelWidthIn $S.labelHeightIn $extraHead $extraBody
}

function Get-TestLabelQuery {
  'c=TEST&n=' + (UrlEnc "Test label $env:COMPUTERNAME") + '&p=' + (UrlEnc (Get-Date -Format 'HH:mm')) + '&d=' + (Get-Date).DayOfWeek + '&x=' + (UrlEnc 'Printed from the BT Print setup page - throw away')
}

# ----------------------------------------------------------------------------- port
$ListenPort = $Port
if ($ListenPort -le 0) { $ListenPort = (Get-Settings).port }

if ($ServeHidden) {
  # Used by the Startup shortcut and the watchdog task: start the listener as a hidden process (no console
  # window in the taskbar, so nobody can close it by accident), then exit. Does nothing if it is already up.
  $busy = $false
  try { $c = New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1', $ListenPort); $busy = $c.Connected; $c.Close() } catch {}
  if (-not $busy) {
    $args = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', $MyInvocation.MyCommand.Path, '-Serve')
    if ($Port -gt 0) { $args += @('-Port', "$Port") }
    Start-Process -FilePath 'powershell.exe' -WindowStyle Hidden -ArgumentList $args | Out-Null
  }
  exit 0
}

if ($Serve) {
  # Minimal HTTP listener on 127.0.0.1:$ListenPort (raw TCP, so no admin/URL-ACL needed).
  try { $listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $ListenPort); $listener.Start() }
  catch { exit 2 }   # port busy = a listener is already running; stay quiet
  Log "SERVE v$HelperVersion listening on http://localhost:$ListenPort/ (pid $PID) settings=$settingsPath"
  $null = Register-EngineEvent -SourceIdentifier PowerShell.Exiting -MessageData $log -Action { Add-Content -Path $Event.MessageData -Value ("{0} SERVE exiting (pid {1})" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $PID) -Encoding UTF8 -ErrorAction SilentlyContinue }
  $serveLoop = {
  while ($true) {
    $client = $null
    try {
      $client = $listener.AcceptTcpClient()
      $client.ReceiveTimeout = 3000
      $stream = $client.GetStream()
      $buf = New-Object byte[] 65536; $total = 0; $reqText = ''
      try {
        do {
          $n = $stream.Read($buf, $total, $buf.Length - $total)
          if ($n -le 0) { break }
          $total += $n
          $reqText = [Text.Encoding]::ASCII.GetString($buf, 0, $total)
        } while (-not $reqText.Contains("`r`n`r`n") -and $total -lt $buf.Length)
      } catch { }   # browsers open idle speculative connections; ignore ones that send nothing
      if ($total -eq 0) { $client.Close(); $client = $null; continue }
      $first = ($reqText -split "`r`n")[0]
      $path = ''
      if ($first -match '^(GET|HEAD)\s+(\S+)') { $path = $Matches[2] }
      $ua = ''; if ($reqText -match "(?im)^User-Agent:\s*(.+?)\s*$") { $ua = $Matches[1] }
      $origin = ''; if ($reqText -match "(?im)^(Origin|Referer):\s*(.+?)\s*$") { $origin = $Matches[2] }
      if ($path) { Log ("REQ {0} | from={1} | ua={2}" -f $path.Substring(0, [Math]::Min(60, $path.Length)), $origin, $ua.Substring(0, [Math]::Min(60, $ua.Length))) }
      else { $raw = ($first -replace '[^\x20-\x7E]', '.'); Log ("REQ unparseable ({0} bytes): {1}" -f $total, $raw.Substring(0, [Math]::Min(80, $raw.Length))) }

      # ---- decide the response (status line + headers, body bytes) and the job to run after answering
      $code = '204 No Content'; $ctype = ''; $bodyBytes = $null; $job = $null; $extraHdr = ''
      $route = $path; if ($route -match '\?') { $route = $route.Substring(0, $route.IndexOf('?')) }
      $route = $route.TrimEnd('/'); if ($route -eq '') { $route = '/' }
      switch -Regex ($route) {
        '^/ping$'         { $code = '200 OK'; $ctype = 'text/plain'; $bodyBytes = [Text.Encoding]::UTF8.GetBytes('ok') }
        '^/(print|test)-close$' {
          # opened in a new window/tab (Zoho One cannot navigate its frame to localhost): a page that closes itself
          $html = '<!doctype html><meta charset="utf-8"><title>Label sent</title><body style="font-family:Arial,sans-serif;text-align:center;padding-top:15vh;color:#1A2530"><h2 style="margin:0 0 8px">Label sent to the printer</h2><p>This tab closes by itself. If it does not, just close it.</p><script>setTimeout(function(){window.close();},400);</script></body>'
          $code = '200 OK'; $ctype = 'text/html; charset=utf-8'; $bodyBytes = [Text.Encoding]::UTF8.GetBytes($html)
          $job = { Invoke-LabelPrint $path $false | Out-Null }
        }
        '^/(print|test)$' { $code = '204 No Content'; $job = { Invoke-LabelPrint $path $false | Out-Null } }
        '^/printers$'     { $code = '200 OK'; $ctype = 'application/json; charset=utf-8'; $bodyBytes = [Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject @(Get-PrinterList) -Depth 3)) }
        '^/status$'       { $code = '200 OK'; $ctype = 'application/json; charset=utf-8'; $bodyBytes = [Text.Encoding]::UTF8.GetBytes((Get-StatusJson)) }
        '^/preview$'      { $code = '200 OK'; $ctype = 'text/html; charset=utf-8'; $bodyBytes = [Text.Encoding]::UTF8.GetBytes((Get-PreviewPage $path)) }
        '^/setup$' {
          $f = Parse-Fields $path; $kv = $f.kv
          $action = [string]$kv['action']; $msg = ''; $warn = $false
          if ($action -eq 'save' -or $action -eq 'test') {
            $S = Get-Settings
            $w = $S.labelWidthIn; $h = $S.labelHeightIn
            $sz = [string]$kv['size']
            if ($sz -eq 'custom') { try { $w, $h = Parse-Size ([string]$kv['w']) ([string]$kv['h']) } catch { $msg = 'Custom size must be two numbers.'; $warn = $true } }
            elseif ($sz -match '^\s*([\d.]+)\s*x\s*([\d.]+)\s*$') { $w, $h = Parse-Size $Matches[1] $Matches[2] }
            if ($w -lt 0.5 -or $w -gt 20 -or $h -lt 0.5 -or $h -gt 20) { $msg = 'Label size must be between 0.5 and 20 inches.'; $warn = $true }
            if (-not [string]$kv['printer']) { $msg = 'Choose a printer first.'; $warn = $true }
            if (-not $warn) {
              $new = @{ printerName = [string]$kv['printer']; paperName = [string]$kv['paper']; labelWidthIn = $w; labelHeightIn = $h; port = $S.port }
              Save-Settings $new
              $msg = 'Saved: ' + $new.printerName + ', paper "' + $new.paperName + '", label ' + (SizeName $w $h) + ' in (' + (Num $w) + ' wide x ' + (Num $h) + ' tall).'
              if ($action -eq 'test') { $msg += ' A test label (CONTAINER "TEST") is being printed - throw it away. If nothing comes out, see /status and the log.'; $tq = Get-TestLabelQuery; $job = { Invoke-LabelPrint "/print?$tq" $false | Out-Null } }
            }
          }
          $code = '200 OK'; $ctype = 'text/html; charset=utf-8'; $bodyBytes = [Text.Encoding]::UTF8.GetBytes((Get-SetupPage $kv $msg $warn))
        }
        '^/$'             { $code = '303 See Other'; $extraHdr = "Location: /setup`r`n" }
        default           { $code = '404 Not Found'; $bodyBytes = [Text.Encoding]::UTF8.GetBytes('') }
      }
      $head = "HTTP/1.1 $code`r`nCache-Control: no-store`r`nConnection: close`r`n$extraHdr"
      if ($null -ne $bodyBytes) {
        if ($ctype) { $head += "Content-Type: $ctype`r`n" }
        $head += "Content-Length: $($bodyBytes.Length)`r`n"
      }
      $head += "`r`n"
      $out = [Text.Encoding]::ASCII.GetBytes($head)
      if ($null -ne $bodyBytes -and $bodyBytes.Length -gt 0) { $out = $out + $bodyBytes }
      try { $stream.Write($out, 0, $out.Length); $stream.Flush() } catch {}
      $client.Close(); $client = $null

      if ($job) {
        try { & $job }
        catch { Log "ERROR $($_.Exception.Message) | $($_.InvocationInfo.PositionMessage -replace '\s+',' ')"; Show-Err $_.Exception.Message }
      }
    }
    catch { Log "SERVE loop error: $($_.Exception.Message)"; if ($client) { try { $client.Close() } catch {} } }
  }
  }  # end of $serveLoop
  # Supervisor: if anything escapes the loop, log it and keep serving instead of exiting.
  while ($true) {
    try { & $serveLoop }
    catch { Log "SERVE fatal: $($_.Exception.Message) | $($_.InvocationInfo.PositionMessage -replace '\s+',' ') -- resuming in 3s"; Start-Sleep 3 }
  }
}
else {
  try {
    $png = Invoke-LabelPrint $Url ([bool]$NoPrint)
    if ($NoPrint) { Write-Output $png }
  }
  catch {
    Log "ERROR $($_.Exception.Message) | $($_.InvocationInfo.PositionMessage -replace '\s+',' ')"
    if ($NoPrint) { Write-Output "ERROR: $($_.Exception.Message)"; Write-Output $_.InvocationInfo.PositionMessage; exit 1 }
    Show-Err $_.Exception.Message
    exit 1
  }
}
