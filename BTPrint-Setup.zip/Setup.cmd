@echo off
:: BT Print helper v2 - setup launcher for the Bedikas Tefilin app.
:: Asks Windows for Administrator permission (normal UAC prompt), then runs Setup-PrintHelper.ps1
:: from this folder in a PowerShell window that stays open until the checkup is finished.
:: Works from the extracted installer (BTPrint-Setup-x.exe) and from the unzipped kit folder alike.
setlocal
set "HERE=%~dp0"
set "HERE=%HERE:~0,-1%"
title BT Print helper setup
echo.
echo  BT Print helper setup - Bedikas Tefilin label printing
echo  ------------------------------------------------------
echo  Windows will now ask for Administrator permission (click Yes).
echo  A blue PowerShell window then installs the helper and runs a checkup.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath 'powershell.exe' -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File \"%HERE%\Setup-PrintHelper.ps1\" %*' -Verb RunAs -Wait"
if errorlevel 1 (
  echo.
  echo  The setup window did not start - permission refused? Run Setup.cmd again and click Yes.
  pause
)
endlocal
